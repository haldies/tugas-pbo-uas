// Final Version :D
public class App {
    public static void main(String[] args) {
        Login login = new Login();

        login.regis();
    }
}
